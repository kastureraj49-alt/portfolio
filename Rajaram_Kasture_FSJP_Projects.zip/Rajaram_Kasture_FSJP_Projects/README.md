# Rajaram Kasture — FSJP Assignment 1 starter projects

This folder contains two beginner-friendly static websites inspired by the structure of the reference assignment PDF:
1. Personal Portfolio
2. Cybersecurity Awareness Demo

## Tools needed
- Visual Studio Code
- A modern browser (Chrome, Edge, Firefox)
- Optional: VS Code extension "Live Server"

## Run locally
1. Extract this ZIP file.
2. Open the extracted `Rajaram_Kasture_FSJP_Projects` folder in VS Code.
3. Open `portfolio/index.html` or `cybersecurity-awareness/index.html`.
4. For the easiest live preview, install the VS Code extension **Live Server** (by Ritwick Dey), right-click `index.html`, and choose **Open with Live Server**.
5. Open each project separately. No server-side setup or npm install is needed.

If you don't want to install an extension, double-click each `index.html` to open it in your browser. Some browsers may limit local navigation between folders; use Live Server if needed.

## Project 1: Portfolio
Files:
- `portfolio/index.html` — content and page structure
- `portfolio/style.css` — theme, layout, responsive styles
- `portfolio/script.js` — mobile navigation and current year

Before submitting:
- Replace `your-email@example.com` with your real email.
- Add your real GitHub and LinkedIn links if you want them shown.
- Only list skills you are comfortable explaining to your teacher.
- Add your own profile photo only if you want one.

## Project 2: Cybersecurity Awareness
Files:
- `cybersecurity-awareness/index.html` — educational page and quiz structure
- `cybersecurity-awareness/style.css` — visual design and responsive styles
- `cybersecurity-awareness/script.js` — mobile navigation and a 3-question client-side quiz

The quiz is educational only. It does not collect or transmit answers and it is not a real security scanner.

## Deploy with GitHub Pages
1. Create a GitHub repository for each project.
2. Upload the files inside each project folder to its repository root (so `index.html` is at the root).
3. On GitHub, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the deployment to finish and use the URL shown in the Pages settings.
6. For the portfolio's second project link to work after deployment, either deploy both repositories under the same account and update that link to the actual cybersecurity website URL, or keep both folders in one repository and adjust the relative link if needed.

## Assignment PDF layout based on the reference
The supplied 8-page example uses:
1. Cover / assignment information and repository/live website links
2. Portfolio home/hero preview
3. Portfolio About, Skills and Projects preview
4. Portfolio source code screenshot (`index.html`)
5. Portfolio source code screenshot (`style.css`)
6. Cybersecurity awareness home preview
7. Cybersecurity feature/quiz preview
8. Cybersecurity source code screenshot

Use your own screenshots and details. Do not copy the other student's personal details or links. The PDF can be prepared after your sites run and you capture screenshots.
